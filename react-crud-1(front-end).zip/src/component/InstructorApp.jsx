import React, { Component } from 'react';
import ListModulesComponent from './ListModulesComponent';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import ModuleComponent from './ModuleComponent';

class InstructorApp extends Component {
    render() {
        return (
            <Router>
                <>
                    <h1>Spring Application</h1>
                    <Switch>
                        <Route path="/" exact component={ListModulesComponent} />
                        <Route path="/modules" exact component={ListModulesComponent} />
                        <Route path="/modules/:id" component={ModuleComponent} />
                    </Switch>
                </>
            </Router>
        )
    }
}

export default InstructorApp