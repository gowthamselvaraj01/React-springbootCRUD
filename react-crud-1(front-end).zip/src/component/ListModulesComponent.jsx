import React, { Component } from 'react'
import ModuleDataService from '../service/ModuleDataService';


class ListModulesComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            modules: [],
            message: null
        }
        this.deleteModuleClicked = this.deleteModuleClicked.bind(this)
        this.updateModuleClicked = this.updateModuleClicked.bind(this)
        this.addModuleClicked = this.addModuleClicked.bind(this)
        this.refreshModules = this.refreshModules.bind(this)
    }

    componentDidMount() {
        this.refreshModules();
    }

    refreshModules() {
        ModuleDataService.retrieveAllModules()//HARDCODED
            .then(
                response => {
                    //console.log(response);
                    this.setState({ modules: response.data })
                }
            )
    }

    deleteModuleClicked(id) {
        ModuleDataService.deleteModule(id)
            .then(
                response => {
                    this.setState({ message: `Delete of module ${id} Successful` })
                    this.refreshModules()
                }
            )

    }

    addModuleClicked() {
        this.props.history.push(`/modules/0`)
    }

    updateModuleClicked(id) {
        console.log('update ' + id)
        this.props.history.push(`/modules/${id}`)
    }

    render() {
        console.log('render')
        return (
            <div className="container">
                <h3>Spring Modules</h3>
                {this.state.message && <div class="alert alert-success">{this.state.message}</div>}
                <div className="container">
                    <table className="table">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Module</th>
                                <th>Version</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.modules.map(
                                    module =>
                                        <tr key={module.id}>
                                            <td>{module.id}</td>
                                            <td>{module.modules}</td>
                                            <td>{module.version}</td>
                                            <td><button className="btn btn-success" onClick={() => this.updateModuleClicked(module.id)}>Update</button></td>
                                            <td><button className="btn btn-warning" onClick={() => this.deleteModuleClicked(module.id)}>Delete</button></td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                    <div className="row">
                        <button className="btn btn-success" onClick={this.addModuleClicked}>Add</button>
                    </div>
                </div>
            </div>
        )
    }
}

export default ListModulesComponent