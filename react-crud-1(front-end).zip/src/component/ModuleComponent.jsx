import React, { Component } from 'react'
import { Formik, Form, Field, ErrorMessage } from 'formik';
import ModuleDataService from '../service/ModuleDataService';


class ModuleComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            modules: '',
            message:null
        }

        this.onSubmit = this.onSubmit.bind(this)
        this.validate = this.validate.bind(this)

    }
    refreshModules() {
        ModuleDataService.retrieveAllModules()
            .then(
                response => {
                    //console.log(response);
                    this.setState({ Modules: response.data })
                }
            )
    }

    componentDidMount() {

        console.log(this.state.id)

        // eslint-disable-next-line
        if (this.state.id == 0) {
            return
        }

        ModuleDataService.retrieveModule(this.state.id)
            .then(response => this.setState({
               // let {modules,version} = response.data,
                modules: response.data.modules,
                version: response.data.version
            }))
    }

    validate(values) {
        let errors = {}
        if (!values.modules) {
            errors.modules = 'Enter a module'
        } else if (values.modules.length < 5) {
            errors.modules = 'Enter atleast 5 Characters in Module'
        }

        return errors

    }

    onSubmit(values) {
        console.log(values);

        let framework = {
            id: this.state.id,
            modules: values.modules,
            version: values.version,
            targetDate: values.targetDate
        }

        if (this.state.id === -1) {
            ModuleDataService.createModule(framework)
                .then(() => this.props.history.push('/modules'))
        } else {
            console.log(framework);
            ModuleDataService.updateModule(framework)
                .then(
                    () => this.props.history.push('/modules')
                // response => {
                //     this.setState({ message: `Updation of module ${this.state.id} Successful` })
                //     //this.refreshModules()
                // }
                )
        }

        console.log(values);
    }

    render() {

        let { modules, id, version} = this.state

        return (
            <div>
                <h3>Module</h3>
                {this.state.message &&<div class="alert alert-success">{this.state.message}</div>}
                <div className="container">
                    <Formik
                        initialValues={{ id, modules,version }}
                        onSubmit={this.onSubmit}
                        validateOnChange={false}
                        validateOnBlur={false}
                        validate={this.validate}
                        enableReinitialize={true}
                    >
                        {
                            (props) => (
                                <Form>
                                    <ErrorMessage name="modules" component="div"
                                        className="alert alert-warning" />
                                    <fieldset className="form-group">
                                        <label>Id</label>
                                        <Field className="form-control" type="text" name="id" disabled />
                                    </fieldset>
                                    <fieldset className="form-group">
                                        <label>Modules</label>
                                        <Field className="form-control" type="text" name="modules" />
                                    </fieldset>
                                    <fieldset className="form-group">
                                        <label>Version</label>
                                        <Field className="form-control" type="text" name="version" />
                                    </fieldset>
                                    <button className="btn btn-success" type="submit">Save</button>
                                </Form>
                            )
                        }
                    </Formik>

                </div>
            </div>
        )
    }
}

export default ModuleComponent