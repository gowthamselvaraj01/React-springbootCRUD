import axios from 'axios'

const MODULE_API_URL = 'http://localhost:8081'

class ModuleDataService {

    retrieveAllModules() {
        
        return axios.get(`${MODULE_API_URL}/getData`);
    }

    retrieveModule(id) {
        
        return axios.get(`${MODULE_API_URL}/getData/${id}`);
    }

    deleteModule(id) {
        
        return axios.delete(`${MODULE_API_URL}/delData/${id}`);
    }

    updateModule(framework) {
        
        return axios.put(`${MODULE_API_URL}/addData`, framework);
    }

    createModule(framework) {
        
        return axios.post(`${MODULE_API_URL}/addData/`, framework);
    }
}

export default new ModuleDataService()